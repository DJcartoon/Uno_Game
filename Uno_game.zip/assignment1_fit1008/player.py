from __future__ import annotations
from card import Card, CardColor, CardLabel
from config import Config
from data_structures import *


class Player:
    """
    Player class to store the player details
    """

    def __init__(self, name: str) -> None:
        """
        Constructor for the Player class

        Args:
            name (str): The name of the player
            position (int): The position of the player

        Returns:
            None

        Complexity:
            Best Case Complexity:o(1)
            Worst Case Complexity:o(1)
        """
        self.name = name
        self.hand = []

    def add_card(self, card: Card) -> None:
        """
        Method to add a card to the player's hand

        Args:
            card (Card): The card to be added to the player's hand

        Returns:
            None

        Complexity:
            Best Case Complexity:o(1)
            Worst Case Complexity:o(1)
        """
        self.hand.append(card)

    def is_empty(self) -> bool:
        """
        Method to check if the player's hand is empty

        Args:
            None

        Returns:
            bool: True if the player's hand is empty, False otherwise

        Complexity:
            Best Case Complexity:o(1)
            Worst Case Complexity:o(1)
        """
        return len(self.hand) ==0

    def cards_in_hand(self) -> int:
        """
        Method to check the number of cards left in the player's hand

        Args:
            None

        Returns:
            int: The number of cards left in the player's hand

        Complexity:
            Best Case Complexity:o(1)
            Worst Case Complexity:o(1)
        """
        return len(self.hand)

    def play_card(
        self, current_color: CardColor, current_label: CardLabel
    ) -> Card | None:
        """
        Method to play a card from the player's hand

        Args:
            current_color (CardColor): The current color of the game
            current_label (CardLabel): The current label of the game

        Returns:
            Card: The first card that is playable from the player's hand

        Complexity:cards in a player hand which is n 
            Best Case Complexity:o(n)
            Worst Case Complexity:o(n)
        """
        # if the card is 1. same colour 2.same label or 3.black colour it is playable 
        #complexity o(n): iterates through all the cards in a player hand which is n 
        playable_cards = [
            card for card in self.hand
            if card.color == current_color or card.label == current_label or card.color == CardColor.BLACK
        ]

        if not playable_cards:# is it empty 
            return None
        
        # Sort by color first, then by label, then play the frist card and remove it from hand 
        playable_cards.sort(key=lambda card: (card.color, card.label))
        card_to_play = playable_cards[0]
        self.hand.remove(card_to_play)
        return card_to_play

    def __str__(self) -> str:
        """
        Return a string representation of the player.

        Optional method for debugging.

        """
        return f"Player {self.name}: {', '.join(map(str, self.hand))}"

    def __repr__(self) -> str:
        """
        Method to return the string representation of the player

        Args:
            None

        Returns:
            str: The string representation of the player
        """
        return str(self)
