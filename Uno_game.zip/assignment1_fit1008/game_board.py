from __future__ import annotations
from card import Card
from random_gen import RandomGen
from config import Config
from data_structures import *
from data_structures.referential_array import ArrayR

class GameBoard:
    """
    GameBoard class to store cards in draw pile and discard pile
    """

    def __init__(self, cards: ArrayList[Card]):
        """
        Constructor for the GameBoard class

        Args:
            cards (ArrayList[Card]): The list of cards to be used in the game

        Returns:
            None

        Complexity:
            Best Case Complexity:o(n)
            Worst Case Complexity:o(n)
        """
        # intialising piles 
        self.draw_pile = ArrayStack(Config.DECK_SIZE)
        self.discard_pile = ArrayStack(Config.DECK_SIZE)

        # pushing the into the draw stack 
        #complexity o(n): where n is the number of cards in the deck
        for card in reversed(cards):
            self.draw_pile.push(card)
            
        
        
        

    def discard_card(self, card: Card) -> None:
        """
        Discards the specified card from the player's hand.

        Args:
            card (Card): The card to be discarded.

        Returns:
            None

        Complexity:
            Best Case Complexity:o(1)
            Worst Case Complexity:o(1)
        """
        
       
        self.discard_pile.push(card)
        


    def reshuffle(self) -> None:
        """
        Reshuffles cards from the discard pile and add them back to the draw pile.

        Args:
            None

        Returns:
            None

        Complexity:O(n)+O(n) 
        where n is the number of cards in discard pile
            Best Case Complexity: o(n)
            Worst Case Complexity:o(n)
        """
        #intiallising variables and array
        tempArray = ArrayR(len(self.discard_pile))
        cardIndex = 0 

        #removing cards from discard pile into list to shuffle
        # Complxity: o(n):where n is the number of cards in discard pile
        while not self.discard_pile.is_empty(): 
            card = self.discard_pile.pop() # stack so can only pop one at a time
            if not (card) :
                raise AttributeError("Card is none")
            
            tempArray[cardIndex] = card
            cardIndex +=1
        RandomGen.random_shuffle(tempArray)

        # taking the shuffled list of cards and pushing them into the stack 
        # Complxity: o(n):where n is the number of cards in discard pile
        while cardIndex !=0: 
            cardIndex -=1
            self.draw_pile.push(tempArray[cardIndex])

    def draw_card(self) -> Card:
        """
        Draws a card from the draw pile.

        Args:
            None

        Returns:
            Card: The card drawn from the draw pile.

        Complexity:
            Best Case Complexity:o(1)
            Worst Case Complexity:o(1)
        """
        if self.draw_pile.is_empty():
            
            self.reshuffle()
        return self.draw_pile.pop()
