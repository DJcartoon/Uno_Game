from __future__ import annotations
from player import Player
from game_board import GameBoard
from card import CardColor, CardLabel, Card
from random_gen import RandomGen
from config import Config
from data_structures import *
from data_structures.queue_adt import CircularQueue

class Game:
    """
    Game class to play the game
    """

    def __init__(self) -> None:
        """
        Constructor for the Game class

        Args:
            None

        Returns:
            None

        Complexity:
            Best Case Complexity: o(1)
            Worst Case Complexity:o(1)
        """
        self.players = None
        self.current_player = None
        self.current_color = None 
        self.current_label = None
        self.game_board = None


        self.player_direction = 'right'

    def generate_cards(self) -> ArrayList[Card]:
        """
        Method to generate the cards for the game

        Args:
            None

        Returns:
            ArrayList[Card]: The list of Card objects generated
        """
        list_of_cards: ArrayList[Card] = ArrayList(Config.DECK_SIZE)
        idx: int = 0

        # Generate 4 sets of cards from 0 to 9 for each color
        for color in CardColor:
            if color != CardColor.BLACK:
                # Generate 4 sets of cards from 0 to 9 for each color
                for i in range(10):
                    list_of_cards.insert(idx, Card(color, CardLabel(i)))
                    idx += 1
                    list_of_cards.insert(idx, Card(color, CardLabel(i)))
                    idx += 1

                # Generate 2 of each special card for each color
                for i in range(2):
                    list_of_cards.insert(idx, Card(color, CardLabel.SKIP))
                    idx += 1
                    list_of_cards.insert(idx, Card(color, CardLabel.REVERSE))
                    idx += 1
                    list_of_cards.insert(idx, Card(color, CardLabel.DRAW_TWO))
                    idx += 1
            else:
                # Generate black crazy and draw 4 cards
                for i in range(4):
                    list_of_cards.insert(idx, Card(CardColor.BLACK, CardLabel.CRAZY))
                    idx += 1
                    list_of_cards.insert(
                        idx, Card(CardColor.BLACK, CardLabel.DRAW_FOUR)
                    )
                    idx += 1

                # Randomly shuffle the cards
                RandomGen.random_shuffle(list_of_cards)

                return list_of_cards

    def initialise_game(self, players: ArrayList[Player]) -> None:
        """
        Method to initialise the game

        Args:
            players (ArrayList[Player]): The list of players

        Returns:
            None

        Complexity:
            Best Case Complexity:
            Worst Case Complexity:
        """
        # setting up players , game board
        self.players = CircularQueue(len(players))

        for player in players:
            self.players.append(player)
            

        self.game_board = GameBoard(self.generate_cards())
        
        
        # while each player not have certain amount of cards in hand 
        for i in range(Config.NUM_CARDS_AT_INIT):
            for player in players:
                self.draw_card(player,False)
                                 
            
    
        
      
         # while If the top card is not a number card, repeat drawing a new one until the top card is a number card. 
                

        draw_card = self.game_board.draw_card() # drawing card from dec 
        while draw_card.label.value > 9: 
            
            self.game_board.discard_card(draw_card) #  discarding the top card 
            draw_card = self.game_board.draw_card()
        
        self.game_board.discard_card(draw_card)
        self.current_color = draw_card.color
        self.current_label = draw_card.label
        

    def next_player(self) -> Player:
        """
        Method to get the next player

        Args:
            None

        Returns:
            Player: The next player

        Complexity:
            Best Case Complexity:
            Worst Case Complexity:
        """
        if not self.players:
                raise ValueError("no players exisit")
        
        next_player = self.players.peek()
        return next_player
        
        # elif self.player_direction == 'right':
        #     current_index = self.players.index(self.current_player)
        #     next_index = (current_index + 1) % len(self.players)  # Move to next player cyclically
        #     next_player = self.players[next_index]

        # elif  self.player_direction == 'left':
        #     current_index = self.players.index(self.current_player)
        #     next_index = (current_index - 1) % len(self.players)  # Move to next player cyclically
        #     next_player = self.players[next_index]
        # return next_player
            

    def reverse_players(self) -> None:
        """
        Method to reverse the order of the players

        Args:
            None

        Returns:
            None

        Complexity: n is the number of players 
            Best Case Complexity: o(1)
            Worst Case Complexity:o(1)
        """

        player_store = ArrayStack(len(self.players))

        # pushing the into the draw stack 
        #complexity o(n): where n is the number of cards in the deck
        while not self.players.is_empty():
            player_store.push(self.players.serve())
        
        while not player_store.is_empty():
            self.players.append(player_store.pop())
        
        


        # if self.player_direction == 'left':
        #     self.player_direction = 'right'
        # else:
        #     self.player_direction = 'left'
       
        



    def skip_next_player(self) -> None:
        """
        Method to skip the next player in the game

        Args:
            None

        Returns:
            None

        Complexity:
            Best Case Complexity:
            Worst Case Complexity:
        """
        
        
        next_player = self.players.serve()        
        self.players.append(next_player) # skipping next player 
        
        
        
        
        # if self.current_player == None: 
        #     self.current_player=self.players[1]

        #     return self.current_player

        # print(self.current_player.name)
        # print()
        # print(self.next_player().name)
        
        # if self.player_direction == 'right':
        #     current_index = self.players.index(self.current_player)
        #     next_index = (current_index + 2) % len(self.players)  # Move to next player cyclically
        #     self.current_player = self.players[next_index]
        #     return self.current_player

        # elif  self.player_direction == 'left':
        #     current_index = self.players.index(self.current_player)
        #     next_index = (current_index - 2) % len(self.players)  # Move to next player cyclically
        #     self.current_player = self.players[next_index]
        #     return self.current_player

        
        
        
        

    def play_draw_two(self) -> None:
        """
        Method to play a draw two card

        Args:
            None

        Returns:
            None

        Complexity:
            Best Case Complexity:
            Worst Case Complexity:
        """
        
        for _ in range(2):
            card_draw = self.game_board.draw_card()
            self.next_player().add_card(card_draw)
        
       

        

    def play_black(self, card: Card) -> None:
        """
        Method to play a crazy card

        Args:
            card (Card): The card to be played

        Returns:
            None

        Complexity:
            Best Case Complexity:
            Worst Case Complexity:
        """
        # Change the game's current color to a random color (excluding black)
        self.current_color = CardColor(RandomGen.randint(0, 3)) 
        # ''' what is redunancy calls'''
        
        
        
        # # If the card is a Draw Four card, apply the draw effect and skip the next player
        if card.label == CardLabel.DRAW_FOUR :
            for _ in range(4):
                self.draw_card(self.next_player(),False)
            
            self.skip_next_player()

        

        

    def draw_card(self, player: Player, playing: bool) -> Card | None:
        """
        Method to draw a card from the deck

        Args:
            player (Player): The player who is drawing the card
            playing (bool): A boolean indicating if the player is able to play the card

        Returns:
            Card - When drawing a playable card, other return None

        Complexity:
            Best Case Complexity:
            Worst Case Complexity:
        """
        
        drawn_card = self.game_board.draw_card()
        

        if ( drawn_card.color == CardColor.BLACK or drawn_card.color == self.current_color or drawn_card.label == self.current_label) and  playing == True:
            
            # remeber to pass the black card through self.play_black when calling this function
            
            return drawn_card
        
        else:
            player.add_card(drawn_card)


        # if  (drawn_card.color == self.current_color or drawn_card.label == self.current_label ):
            
        #     return drawn_card
        # elif drawn_card.label == CardColor.BLACK :
            
        #     #self.play_black(drawn_card)'
        #     return drawn_card

        # elif drawn_card.label == CardLabel.DRAW_TWO  :
        #     if playing:
        #         return drawn_card

        # else:
        #     self.current_player.add_card(drawn_card)

    def play_game(self) -> Player:
        """
        Method to play the game

        Args:
            None

        Returns:
            Player: The winner of the game
        """
        
        # starts game 
        
        self.current_player = self.players.serve()
        self.players.append(self.current_player)
        t = 0
        # game ends when current player plays last card 
        while len(self.current_player.hand)  !=0  :

            if  t != 0 :
                self.current_player = self.players.serve()
                self.players.append(self.current_player)
            t +=1


            playable_card = self.current_player.play_card(self.current_color,self.current_label)

            # player dosen't have any cards to play pick up CARD
            if  playable_card is None:# is none 
                playable_card = self.draw_card(self.current_player,True) #draw _card is a playable

                
                if playable_card is None  :
                    continue
            self.current_color  == playable_card.color 
            self.current_label == playable_card.label 

                         

                

            if playable_card.label <= 9 :
                # normal card
                
                self.game_board.discard_card(playable_card)
            elif playable_card.label > 9:
                
                ''' IMPLEMENT'''
                if  playable_card.color == CardColor.BLACK:
                    self.play_black(playable_card)

                elif  playable_card.label == CardLabel.DRAW_TWO:
                    self.play_draw_two()
                    
                elif  playable_card.label == CardLabel.REVERSE:
                    self.reverse_players()
                    self.current_player = self.players.serve()
                    self.players.append(self.current_player)
                
                elif  playable_card.label == CardLabel.SKIP:
                    self.skip_next_player()

                else:
                    raise Exception(f"card is playable, but not speacial {playable_card}")
            else:
                raise Exception(f"card playablity failed: {playable_card}")       
        
                
        return  self.current_player
    
        

